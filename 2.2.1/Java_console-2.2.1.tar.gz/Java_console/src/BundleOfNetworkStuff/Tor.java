package BundleOfNetworkStuff;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Running the NEWNYM feature on Tor
 * 
 * http://dimio.org/tor-newnym-avtomaticheskaya-smena-ip-v-tor.html
 * http://gitweb.torproject.org/torspec.git/tree/control-spec.txt
 * 
 * @author Nikodim
 *
 */
public class Tor {

	private String host = "127.0.0.1"; // Tor's control host;
	private int port = 9051; // Tor's control port (ControlPort in the "/etc/tor/torrc" file);
	private String password = "my_new_password"; // for "HashedControlPassword" in the "/etc/tor/torrc" file (tor --hash-password 'new_tor_password');
	private String codepage = "UTF-8";

	/**
	 * This constructor defines which host, port and password
	 * (for "HashedControlPassword" in the "/etc/tor/torrc" file) are going to be used.
	 * @param host
	 * @param port
	 * @param password
	 * @param codepage
	 */
	public Tor(String host, int port, String password, String codepage) {
		this.host = (((host == null) || (host.isEmpty())) ? this.host : host);
		this.port = ((((port < 1) || (port > 65535)) ? this.port : port));
		this.password = (((password == null) || (password.isEmpty())) ? this.password : password);
		this.codepage = (((codepage == null) || (codepage.isEmpty())) ? this.codepage : codepage);
	}

	/**
	 * Invoking the NEWNYM signal on Tor to change the circuits
	 * @throws UnknownHostException
	 * @throws IOException
	 */
	public void setNEWNYM() throws UnknownHostException, IOException {
		final int TIMEOUT = 10000, TIMEOUT_curr = 1000 / 2;
		final String[] cmd = new String[] {
				"AUTHENTICATE \"" + this.password + "\"",
				"SETEVENTS SIGNAL",
				"SIGNAL NEWNYM",
				"QUIT"
		};

		Socket inoutSocket = new Socket();
		inoutSocket.connect(new InetSocketAddress(this.host, this.port), TIMEOUT);

		BufferedReader in = new BufferedReader(new InputStreamReader(inoutSocket.getInputStream(), this.codepage));
		PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(inoutSocket.getOutputStream(), this.codepage)), true);

		for (String sCmd : cmd) {
			System.out.println(sCmd);
			out.println(sCmd);
			out.flush();
			try {
				Thread.sleep(TIMEOUT_curr); // pause
			}
			catch (InterruptedException e) {}
			String line01;
			if (in.ready()) {
				line01 = in.readLine();
				System.out.println(line01);
			}
		}

		in.close();
		out.close();
		inoutSocket.close();

		System.out.println("\n\nEnd of commands");
	}

}
