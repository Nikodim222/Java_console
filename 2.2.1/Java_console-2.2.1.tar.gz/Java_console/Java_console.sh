#!/bin/sh
export TZ='Asia/Novosibirsk'

export jdkbin="/opt/jdk1.8.0_20/bin"

# полный путь до скрипта
export ABSOLUTE_FILENAME=`readlink -e "$0"`
# каталог, в котором лежит скрипт
export DIRECTORY=`dirname "$ABSOLUTE_FILENAME"`

$jdkbin/java -jar $DIRECTORY/bin/Java_console.jar "$@"

if [ $? -eq 0 ]
   then
      echo "\nThe application has been successfully finished."
   else
      echo "\nAn error has occurred while running the application."
fi
