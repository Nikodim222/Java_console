#!/bin/sh
export project="Java_console"

echo Compiling $project into a JAR file...

rm -Rf ./bin_temp
mkdir -p ./bin_temp && javac -g -nowarn -classpath ./src -cp "./mysql-connector-java-5.1.34-bin.jar:./ojdbc6.jar:./SimpleWebServer.jar:./src" -sourcepath "./src" -d ./bin_temp ./src/main/startIt.java
# java -cp "./mysql-connector-java-5.1.34-bin.jar:./ojdbc6.jar:./SimpleWebServer.jar:./bin_temp" -classpath "./mysql-connector-java-5.1.34-bin.jar:./ojdbc6.jar:./SimpleWebServer.jar:./bin_temp" main.startIt
jar mcvf ./my_MANIFEST.MF ./$project.jar -C bin_temp/ .
rm -Rf ./bin_temp
chmod -wx+r ./$project.jar

echo See the file of ./$project.jar
echo Run it as follows,
echo java -jar ./$project.jar
sleep 5
