/**
 * The World's Java Console
 * by Nikodim 
 * 
 * This has been made in Eclipse 4.4.1 "Luna" (http://www.eclipse.org).
 * Feel free to extend the code with a newer functionality if required.
 * I won't charge any duty from you.
 * Have fun!
 */

package main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;

import files.BasicOperations; // linking the handy BasicOperations class

import main.Commands;

import org.jibble.simplewebserver.SimpleWebServer; // "Java Mini Web Server" (http://www.jibble.org/miniwebserver/)

public class startIt {
	public static final String sysHome = new String("user.home");
	public static final String fileSeparator = new String("file.separator");

	static {
		System.out.println("--- The World's Java Console ---");
		System.out.println("Type 'exit' to quit, 'help' to see the list of commands.");
	}

	public interface Function<From1, To1> {
		To1 apply(From1 from);
	}

	/**
	 * This Java class contains network settings.
	 * @author Nikodim
	 */
	public static class NetworkSettings {
		public String codepage = new String();
		public String proxyhost = new String();
		public int proxyport = 0;
		public String uName = new String();
		public String uPass = new String();
		public String[] noproxy = new String[] {};
	}

	/**
	 * This Java class contains Oracle settings.
	 * @author Nikodim
	 */
	public static class OracleSettings {
		public String oracle_user = new String();
		public String oracle_password = new String();
		public String oracle_url = new String(); // "jdbc:oracle:thin:@10.242.4.2:1525:REG1"
		public String oracle_ctrl_line = new String(); // "java.sql.Driver"
		public int oracle_col_size = 0;
		public String oracle_query = new String();
	}

	/**
	 * This Java class contains MySQL settings.
	 * @author Nikodim
	 */
	public static class MySQLSettings {
		public String mysql_user = new String();
		public String mysql_password = new String();
		public String mysql_url = new String(); // "jdbc:mysql://localhost:3306/mysql"
		public String mysql_ctrl_line = new String(); // "java.sql.Driver"
		public int mysql_col_size = 0;
		public String mysql_codepage = new String();
		public String mysql_query = new String();
	}

	public static void greppedFile(String fileMGrep, String grepPatternMGrep, NetworkSettings objNetworkSettings, String defaultCodepage) {
		try {
			System.out.println("Looking up the pattern in the file. This may take a while...");
			int x = 0;
			for (String sTemp08 : new BasicOperations(fileMGrep, fileMGrep).readTextFile(((objNetworkSettings.codepage.isEmpty()) ? defaultCodepage : objNetworkSettings.codepage.toString()))) {
				if (sTemp08.toLowerCase().lastIndexOf(grepPatternMGrep.toLowerCase()) > -1) {
					System.out.println("\"" + sTemp08 + "\"");
					x++;
				}
			}
			if (x < 1) {
				System.out.println("None has been found according to the pattern.");
			} else {
				System.out.println("There have been totally " + String.valueOf(x) + " lines found, according to the pattern.");
			}
		}
		catch (Exception e) {
			System.err.println("The file cannot be read out.");
		}
	}

	public static void _changed(String par) {
		StringBuilder obj = new StringBuilder();
		obj.append(par);
		obj.append(" has been changed.");
		System.out.println(obj.toString());
	}

	public static String pathConverted(String path, String defaultDir) {
		return new BasicOperations("", "").pathConverted(path, defaultDir, sysHome, fileSeparator);
	}

	private static class myPrompt {

		private String promptLine;

		public myPrompt(String s) {
			this.promptLine = s;
		}

		public String thisCommand(String codepage, String defaultCodepage) throws IOException {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in, (((codepage == null) || (codepage.isEmpty())) ? defaultCodepage : codepage)));
			System.out.print(this.promptLine + "> ");
			return in.readLine();
		}

	}

	public static final String errorMsg01 = new String("Invalid Input");

	public static String result(boolean foo) {
		final String good = new String("Success.");
		final String bad = new String("Failure.");
		if (foo) {
			return good;
		}
		return bad;
	}

	public static void main(String[] args) {
		NetworkSettings objNetworkSettings = new NetworkSettings();
		OracleSettings objOracleSettings = new OracleSettings();
		MySQLSettings objMySQLSettings = new MySQLSettings();
		final int defaultProxyPort = 3128; // the port by default
		final String defaultCodepage = "UTF-8";
		final int HigherColLim = 79;
		int tempVar01 = 0;
		final int ARGLIM = 10; // peak number of arguments
		final String defaultDir = new String(System.getProperty(sysHome));
		final String cantChngDir = new String("The directory cannot be changed.");
		final String unavailable = new String("N/A");
		final String undef = new String("The parameter is undefined.");
		SimpleWebServer httpServer = null;

		int x = 0;
		String[] argsArray = new String[ARGLIM];
		myPrompt mp_obj = new myPrompt("Waiting for your input");
		ArrayList<String> lst_obj = new ArrayList<String>();
		String s = new String();
		String s_converted = new String();

		for (;;) { // infinite loop
			try {
				s = mp_obj.thisCommand(objNetworkSettings.codepage, defaultCodepage);
			}
			catch (Exception e) {
				System.err.println();
				System.err.println(errorMsg01);
			}
			if (
					new Commands(
							objNetworkSettings,
							objOracleSettings,
							objMySQLSettings,
							defaultProxyPort,
							defaultCodepage,
							HigherColLim,
							tempVar01,
							defaultDir,
							cantChngDir,
							unavailable,
							undef,
							httpServer,
							x,
							argsArray,
							lst_obj,
							s,
							s_converted
							).execCommand()
					) {
				break;
			}

		} // end of the infinite loop

		System.out.println("Good-bye!");
		System.out.println();

		java.util.Calendar calendar = java.util.Calendar.getInstance(java.util.TimeZone.getDefault(), java.util.Locale.getDefault());
		calendar.setTime(new java.util.Date());
		System.out.println("* Copyleft " + String.valueOf(calendar.get(java.util.Calendar.YEAR)) + " Nikodim");
		System.out.println("*");
		System.out.println("* Redistribution and use in source and binary forms, with or without modification, are permitted.");

		System.exit(0);
	}

}