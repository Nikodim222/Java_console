package BundleOfNetworkStuff;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.Socket;

public final class SocketOverProxyFactory {
	private final String host;
	private final int port;
	private String proxyHost;
	private int proxyPort;
	private boolean authProxy;
	private boolean _viaProxy;
	private String codepage;
	private final int TIMEOUT = 10000;

	private Socket socket = null;
	public BufferedReader in = null;
	public PrintWriter out = null;

	public SocketOverProxyFactory(final String host, final int port, final String proxyHost, final int proxyPort, final String proxyUser, final String proxyPassword, final boolean authProxy, final boolean _viaProxy, final String codepage) throws IOException {
		this.host = host;
		this.port = port;
		this.proxyHost = proxyHost;
		this.proxyPort = proxyPort;
		this.authProxy = authProxy;
		this._viaProxy = _viaProxy;
		this.codepage = codepage;

		if (!this._viaProxy) { // without a proxy server
			this.socket = new Socket(Proxy.NO_PROXY);
		} else { // with a proxy server
			if (this.authProxy) {
				Authenticator.setDefault(
						new Authenticator() {
							@Override
							public PasswordAuthentication getPasswordAuthentication() {
								return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
							}
						}
						);
			}
			this.socket = new Socket(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(InetAddress.getByName(this.proxyHost), this.proxyPort)));
		}
		try {
			this.socket.connect(new InetSocketAddress(InetAddress.getByName(this.host), this.port), this.TIMEOUT); // opening the socket connection
		}
		catch (InternalError e) {
			this.socket = null;
			throw new IOException("Proxy authentication failure");
		}
		String myCodepage = ((this.codepage.isEmpty()) ? "UTF-8" : this.codepage.toString());
		this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream(), myCodepage));
		this.out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream(), myCodepage)), true);
	}

	public void close() throws IOException {
		if (this.out != null) {
			this.out.flush();
			this.out.close();
		}
		if (this.in != null) {
			this.in.close();
		}
		if (this.socket != null) {
			this.socket.close();
		}
	}

}
