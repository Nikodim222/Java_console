package main;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;

import org.jibble.simplewebserver.SimpleWebServer;

import BundleOfNetworkStuff.DroneBL;
import BundleOfNetworkStuff.SocketXT;
import BundleOfNetworkStuff.Tor;
import BundleOfNetworkStuff.WhoIs;
import Databases.MySQL_DB;
import Databases.Oracle_DB;
import Databases.Tables;
import coder.Coding;
import files.BasicOperations;
import files.External;
import main.startIt.Function;
import main.startIt.NetworkSettings;
import main.startIt.OracleSettings;
import main.startIt.MySQLSettings;

/**
 * This class processes commands having been typed by a user.
 * @author Nikodim
 *
 */
public final class Commands {
	private NetworkSettings objNetworkSettings;
	private OracleSettings objOracleSettings;
	private MySQLSettings objMySQLSettings;
	private int defaultProxyPort;
	private String defaultCodepage;
	private int HigherColLim;
	private int tempVar01;
	private String defaultDir;
	private String cantChngDir;
	private final String[] cmdList = new String[] {
			"help", "Returns a list of commands which are available for usage.\nUsage: help",
			"history", "The program keeps track of what you've been typing via a command-line interface.\nWhen you invoke this command, it prints a list of commands which you've run before.\nUsage: history",
			"clear", "Clears the history of commands. Also, see \"history\".\nUsage: clear",
			"ver", "This returns the version of a Java virtual machine (JVM), you are using.\nUsage: ver",
			"uname", "Synonymic to \"ver\".",
			"resetdir", "The command tries to redirect the user to the home directory if it is possible to do on the current Java virtual machine (JVM).\nUsage: resetdir",
			"more", "Prints a text file onto the screen.\nUsage: more some_text_file.ext",
			"read", "Synonymic to \"more\".",
			"type", "Synonymic to \"more\".",
			"say", "This command displays a line of text.\n Usage: say Hello World!",
			"echo", "Synonymic to \"say\".",
			"copy", "This copies one file to another.\nUsage: copy some_file_1.ext some_file_2.ext",
			"cp", "Synonymic to \"copy\".",
			"fc", "The diff utility is a data comparison tool that returns whether there are differences between two files or not.\nUsage: fc file1.ext file2.ext",
			"diff", "Synonymic to \"fc\".",
			"size", "Returns the file's size (in bytes).\nUsage: size file.ext",
			"mv", "The command moves or renames a file.\nUsage: mv some_file_1.ext some_file_2.ext",
			"rename", "Synonymic to \"mv\".",
			"ren", "Synonymic to \"mv\".",
			"erase", "This erases a file.\nUsage: erase some_file.ext",
			"rm", "Synonymic to \"erase\".",
			"del", "Synonymic to \"erase\".",
			"delete", "Synonymic to \"erase\".",
			"getname", "This command returns the absolute path of a file or a directory.\nUsage: getname ../myFolder/poem.txt",
			"dir", "Prints directory contents.\nUsage: dir some_directory",
			"mlist", "Prints directory contents by a pattern (mask).\nUsage: mlist path pattern\nFor example:\nmlist /home/user/docs .txt\nThis will be looking for all the files and directories, having the '.txt' thing in their names.",
			"ls", "Synonymic to \"dir\".",
			"cd", "The command causes the named directory to become the current working one.\nUsage: cd new_directory",
			"chdir", "Synonymic to \"cd\".",
			"url", "It's a good tool for non-interactive printing of a text file from The World Wide Web (WWW, W3) onto the screen.\nIt can work either over a proxy connection or direct access. It supports HTTP only.\nUsage: url http://someserver.com/some_directory/file.ext\nAlso, see \"network\".",
			"wget", "Synonymic to \"url\".",
			"dump", "Saves the history to a text file.\nUsage: dump some_file.txt\nAlso, see \"history\".",
			"date", "Prints the system date and time.\nUsage: date",
			"time", "Synonymic to \"date\".",
			"codepage", "This specifies the codepage for using when getting some text file on the Internet (if the connection is established) or thru a local path.\nUsage: codepage Windows-1251\nAlso, see \"wget\", \"more\".",
			"proxyhost", "Assigns a proxy host to be used during connection establishment.\nUsage: proxyhost proxy.server.com",
			"proxyport", "Assigns a proxy port to be used during connection establishment.\nUsage: proxyport 3128",
			"proxyuser", "Assigns a proxy username to be used during connection establishment if proxy authentication is required.\nUsage: proxyuser bob",
			"proxypassword", "Assigns a proxy password to be used during connection establishment if proxy authentication is required.\nUsage: proxypassword secret_word",
			"noproxy", "The noproxy environment variable should contain a comma-separated list of domain extensions proxy should not be used for.\nUsage: noproxy 127.0.0.0/8,localhost,172.16.0.0/16,10.242.0.0/16,.local,.server.com,www.myhomepage.org",
			"no-proxy", "Synonymic to \"noproxy\".",
			"no_proxy", "Synonymic to \"noproxy\".",
			"netcalc", "This command returns a range for an IPv4 subnet by its CIDR notation.\nUsage: netcalc 192.168.100.0/22",
			"cidr", "Synonymic to \"netcalc\".",
			"ff", "This command recursively finds files and directories by a pathname.\nUsage: ff pathname",
			"find", "Synonymic to \"ff\".",
			"network", "This command prints connection properties.\nUsage: network",
			"connection", "Synonymic to \"network\".",
			"webpage2file", "This saves a text file from the Net to the local file.\nUsage: webpage2file http://server.com/index.html myfile.htm",
			"binaryurl2file", "This saves a binary file from the Web to the local place on the system.\nUsage: binaryurl2file http://server.com/misc/game.zip game34.zip",
			"oracle_user", "Specifies which username is used for connection establishment to an Oracle DBMS.\nUsage: oracle_user ora_user",
			"oracle_password", "Specifies what password is used for connection establishment to an Oracle DBMS.\nUsage: oracle_password secret_word",
			"oracle_url", "This defines what URL must be used for connection establishment to an Oracle DBMS.\nUsage: oracle_url jdbc:oracle:thin:@10.242.4.2:1525:REG1",
			"oracle_ctrl_line", "This specifies the control line for the Oracle DBMS driver to be invoked while attempting to establish a connection.\nUsage: oracle_ctrl_line java.sql.Driver",
			"oracle_col_size", "Sets the columns' size in tables while retrieving data from an Oracle database.",
			"use_old_oracle", "Crutches for fixing the \"ORA-01882: timezone region not found\" bug for a newer ojdbc driver.\nSee also http://stackoverflow.com/questions/9156379/ora-01882-timezone-region-not-found\nUsage: use_old_oracle true\nuse_old_oracle false",
			"oracle_query", "The command sends an SQL query to the Oracle DBMS, which you've pointed, and waits for some reponse from it, then.\nUsage: oracle_query SELECT * FROM v$version;",
			"oracle_file2query", "This command loads a file with an Oracle SQL query and fetches a result from it.\nUsage: oracle_file2query file_name.sql",
			"oracle_settings", "Prints the Oracle connection settings on the screen.\nUsage: oracle_settings",
			"mysql_user", "Specifies which username is used for connection establishment to a MySQL DBMS.\nUsage: mysql_user mysql_user",
			"mysql_password", "Specifies what password is used for connection establishment to a MySQL DBMS.\nUsage: mysql_password secret_word",
			"mysql_url", "This defines what URL must be used for connection establishment to a MySQL DBMS.\nUsage: mysql_url jdbc:mysql://localhost:3306/mysql",
			"mysql_ctrl_line", "This specifies the control line for the MySQL DBMS driver to be invoked while attempting to establish a connection.\nUsage: mysql_ctrl_line java.sql.Driver",
			"mysql_col_size", "Sets the columns' size in tables while retrieving data from a MySQL database.",
			"mysql_codepage", "Defines what codepage is going to be used when working with a MySQL database.\nUsage: mysql_codepage cp1251",
			"mysql_query", "The command sends an SQL query to the MySQL DBMS, which you've pointed, and waits for some reponse from it, then.\nUsage: mysql_query SELECT VERSION();",
			"mysql_file2query", "This command loads a file with a MySQL SQL query and fetches a result from it.\nUsage: mysql_file2query file_name.sql",
			"mysql_settings", "Prints the MySQL connection settings on the screen.\nUsage: mysql_settings",
			"iconv", "Converts encoding of the given file from one encoding to another.\nUsage: iconv codepage1 _file1 codepage2 _file2",
			"charsets", "This prints a list of all the available codepages.\nUsage: charsets",
			"hint", "This hints at how the given command should be used.\nUsage: hint command_to_be_hinted",
			"exit", "This command causes normal process termination.\nUsage: exit",
			"quit", "Synonymic to \"exit\".",
			"printenv", "This prints all the environment variables.\nUsage: printenv",
			"exec", "This command executes an external command or program under the operating system.\nUsage: exec external_command_or_file",
			"mim", "This parses a file in the MIM (Multipurpose Internet Mail Extensions) format.\nUsage: mim file_name from_codepage to_codepage",
			"mim2file", "This parses a file in the MIM (Multipurpose Internet Mail Extensions) format and writes the output to another file.\nUsage: mim2file from_file from_codepage to_codepage to_file",
			"grep", "\"grep\" is a command-line utility for searching plain-text data sets for lines matching a regular expression.\nUsage: grep file.ext pattern",
			"mem", "Reports how much memory is occupied by this program, and free memory.\nUsage: mem",
			"mkdir", "This creates a new directory.\nUsage: mkdir dir_name",
			"md", "Synonymic to \"mkdir\".",
			"rmdir", "This deletes a new directory.\nUsage: rmdir dir_name",
			"rd", "Synonymic to \"rmdir\".",
			"ftp", "This command invokes an FTP client.\nUsage: ftp",
			"whois", "This command returns a WHOIS information (RFC 954) for the given IP address.\nUsage: whois 8.8.8.8",
			"dnsbl", "This command returns the status of an IP address whether or not it is blacklisted on the network.\nUsage: dnsbl 8.8.8.8\nDomain Name System Blacklists, also known as DNSBL's or DNS Blacklists, are spam blocking lists that allow a website administrator to block messages from specific systems that have a history of sending spam.",
			"mgrep", "Does basically the same as 'grep', but with many files at a time.\nUsage: mgrep path file_pattern text_pattern\nSee also 'grep'.",
			// "http", "This command starts or stops an HTTP web server of \"Java Mini Web Server\" (http://www.jibble.org/miniwebserver/).\nSyntax:\nhttp status\nhttp stop\nhttp start /home/www 80\nwhere:\n/home/www is an example of a home directory with a web site;\n80 is an example of a TCP port that the server is configured to listen on.\nA user may work and do anythig else while this server is running in the background."
			"http", "This command starts or stops an HTTP web server of \"Java Mini Web Server\" (http://www.jibble.org/miniwebserver/).\nSyntax:\nhttp status\nhttp start /home/www 80\nwhere:\n/home/www is an example of a home directory with a web site;\n80 is an example of a TCP port that the server is configured to listen on.\nA user may work and do anythig else while this server is running in the background.",
			"newnym", "This sends the NEWNYM signal (http://gitweb.torproject.org/torspec.git/tree/control-spec.txt) when using a proxy server that works with Tor.\nThis command may be useful when you want to change your public IP address on the Internet.\nUsage:\nnewnym 127.0.0.1 9051 my_password\nwhere:\nthe 1st parameter is an IP address for Tor;\nthe 2nd parameter is its port it listens on;\nthe 3rd parameter is a bare password that is used for \"HashedControlPassword\" in the \"/etc/tor/torrc\" file (tor --hash-password 'my_password').",
			"rcfdf", "\"rcfdf\" stands for \"Run Commands From a Dump File\".\nIt runs all the commands that are in a file chosen by a user.\nTo create such a file, see the command of \"dump\" by typing \"hint dump\"."
	};
	private String unavailable;
	private String undef;
	private SimpleWebServer httpServer;
	private int x;
	private String[] argsArray;
	private ArrayList<String> lst_obj;
	private String s;
	private String s_converted;

	public Commands(
			NetworkSettings objNetworkSettings,
			OracleSettings objOracleSettings,
			MySQLSettings objMySQLSettings,
			final int defaultProxyPort,
			final String defaultCodepage,
			final int HigherColLim,
			int tempVar01,
			final String defaultDir,
			final String cantChngDir,
			final String unavailable,
			final String undef,
			SimpleWebServer httpServer,
			int x,
			String[] argsArray,
			ArrayList<String> lst_obj,
			String s,
			String s_converted
			) {
		this.objNetworkSettings = objNetworkSettings;
		this.objOracleSettings = objOracleSettings;
		this.objMySQLSettings = objMySQLSettings;
		this.defaultProxyPort = defaultProxyPort;
		this.defaultCodepage = defaultCodepage;
		this.HigherColLim = HigherColLim;
		this.tempVar01 = tempVar01;
		this.defaultDir = defaultDir;
		this.cantChngDir = cantChngDir;
		this.unavailable = unavailable;
		this.undef = undef;
		this.httpServer = httpServer;
		this.x = x;
		this.argsArray = argsArray;
		this.lst_obj = lst_obj;
		this.s = s;
		this.s_converted = s_converted;
	}

	public boolean execCommand() {
		boolean _isExit = false;
		if (this.s == null) {
			System.err.println();
			System.err.println(main.startIt.errorMsg01);
		} else {
			switch (this.s) {
			case "":
				System.out.println("You've written none.");
				break;
			default:
				System.out.println("You've written '" + s + "'.");
				break;
			}
			this.s_converted = this.s.trim();
			this.lst_obj.add(this.s);
			if ((this.s_converted.equals("exit")) || (this.s_converted.equals("quit"))) {
//				if ((this.httpServer != null) && (this.httpServer.isAlive())) {
//					this.httpServer.stop();
//				}
				_isExit = true;
			} else {
				/**
				 * Commands with no arguments (consisting of a single word in a command line)
				 */
				switch (this.s_converted.toLowerCase()) {
				case "history":
					for (this.x = 0; this.x < this.lst_obj.size(); this.x++) {
						System.out.println(this.lst_obj.get(this.x));
					}
					break;
				case "mem":
					long freemem = Runtime.getRuntime().freeMemory();
					System.out.println("Occupied: " + String.valueOf(Runtime.getRuntime().totalMemory() - freemem) + " bytes.");
					System.out.println("Free: " + String.valueOf(freemem) + " bytes.");
					break;
				case "ftp":
					new BasicOperations("", "").ftp(this.defaultDir, main.startIt.sysHome, main.startIt.fileSeparator);
					break;
				case "oracle_settings":
					System.out.println("oracle_user: " + ((this.objOracleSettings.oracle_user.isEmpty()) ? this.unavailable : this.objOracleSettings.oracle_user.toString()));
					System.out.println("oracle_password: " + ((this.objOracleSettings.oracle_password.isEmpty()) ? this.unavailable : this.objOracleSettings.oracle_password.toString()));
					System.out.println("oracle_url: " + ((this.objOracleSettings.oracle_url.isEmpty()) ? this.unavailable : this.objOracleSettings.oracle_url.toString()));
					System.out.println("oracle_ctrl_line: " + ((this.objOracleSettings.oracle_ctrl_line.isEmpty()) ? this.unavailable : this.objOracleSettings.oracle_ctrl_line.toString()));
					System.out.println("oracle_col_size: " + ((this.objOracleSettings.oracle_col_size < 1) ? this.unavailable : String.valueOf(this.objOracleSettings.oracle_col_size)));
					System.out.println("Last used SQL query: " + ((this.objOracleSettings.oracle_query.isEmpty()) ? this.unavailable : this.objOracleSettings.oracle_query.toString()));
					break;
				case "mysql_settings":
					System.out.println("mysql_user: " + ((this.objMySQLSettings.mysql_user.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_user.toString()));
					System.out.println("mysql_password: " + ((this.objMySQLSettings.mysql_password.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_password.toString()));
					System.out.println("mysql_url: " + ((this.objMySQLSettings.mysql_url.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_url.toString()));
					System.out.println("mysql_ctrl_line: " + ((this.objMySQLSettings.mysql_ctrl_line.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_ctrl_line.toString()));
					System.out.println("mysql_col_size: " + ((this.objMySQLSettings.mysql_col_size < 1) ? this.unavailable : String.valueOf(this.objMySQLSettings.mysql_col_size)));
					System.out.println("mysql_codepage: " + ((this.objMySQLSettings.mysql_codepage.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_codepage.toString()));
					System.out.println("Last used SQL query: " + ((this.objMySQLSettings.mysql_query.isEmpty()) ? this.unavailable : this.objMySQLSettings.mysql_query.toString()));
					break;
				case "clear":
					this.lst_obj.clear();
					System.out.println("The commands' history has been erased.");
					break;
				case "printenv": // http://spec-zone.ru/RU/Java/Tutorials/essential/environment/env.html
					new External().printEnvs();
					break;
				case "pwd":
					System.out.println(System.getProperty(main.startIt.sysHome)); // http://www.helloworld.ru/texts/comp/lang/java/java/12.htm
					break;
				case "charsets":
					Object[] availCPs = Charset.availableCharsets().values().toArray();
					for (Object sTemp05 : availCPs) {
						System.out.println(sTemp05.toString());
					}
					System.out.println("Found: " + String.valueOf(availCPs.length) + " item(s).");
					break;
				case "ver": case "uname":
					System.out.println(System.getProperty("java.vendor") + ": Java " + System.getProperty("java.version") + "/" + System.getProperty("os.name"));
					break;
				case "resetdir":
					try {
						System.setProperty(main.startIt.sysHome, this.defaultDir);
						System.out.println("You've been redirected to the default directory.");
						break;
					}
					catch (Exception e) {
						System.err.println(this.cantChngDir);
						break;
					}
				case "help": case "?":
					String[] cmdListTemp = new String[this.cmdList.length / 2];
					for (this.x = 0; this.x < this.cmdList.length / 2; this.x++) {
						cmdListTemp[this.x] = this.cmdList[2 * this.x];
					}
					System.out.println(Arrays.toString(cmdListTemp));
					break;
				case "date": case "time":
					java.util.Calendar today = java.util.Calendar.getInstance();
					System.out.println(today.getTime());
					break;
				case "network": case "connection":
					System.out.println("Codepage: " + ((this.objNetworkSettings.codepage.isEmpty()) ? this.unavailable : this.objNetworkSettings.codepage.toString()));
					System.out.println("Connection: " + ((this.objNetworkSettings.proxyhost.isEmpty()) ? "DIRECT" : "PROXY"));
					if (!(this.objNetworkSettings.proxyhost.isEmpty())) { // if thru a proxy server
						System.out.println("Host: " + this.objNetworkSettings.proxyhost.toString());
						System.out.println("Port: " + Integer.toString((this.objNetworkSettings.proxyport < 1) ? this.defaultProxyPort : this.objNetworkSettings.proxyport));
						System.out.println("Proxy user: " + ((this.objNetworkSettings.uName.isEmpty()) ? this.unavailable : this.objNetworkSettings.uName.toString()));
						System.out.println("Proxy password: " + ((this.objNetworkSettings.uPass.isEmpty()) ? this.unavailable : this.objNetworkSettings.uPass.toString()));
						System.out.println("No-proxy: " + ((this.objNetworkSettings.noproxy.length == 0) ? this.unavailable : Arrays.toString(this.objNetworkSettings.noproxy)));
					}
					break;
				}
				String[] arrTemp = new String[] {};
				arrTemp = this.s_converted.split(" ");
				for (this.x = 0; this.x < this.argsArray.length; this.x++) {
					this.argsArray[this.x] = null; // nulling the array's items
				}
				if (arrTemp.length > this.argsArray.length) {
					for (this.x = 0; this.x < this.argsArray.length; this.x++) {
						this.argsArray[this.x] = arrTemp[this.x]; 
					}
				} else {
					this.x = -1;
					for (String sTemp : arrTemp) {
						this.argsArray[++this.x] = sTemp;
					}
				}

				/**
				 * Commands with arguments (allowed from 1 through 10 parameters)
				 */		
				switch (this.argsArray[0].toLowerCase()) {
				case "more": case "read": case "type":
					try {
						System.out.println("Opening the file of '" + main.startIt.pathConverted(this.argsArray[1], this.defaultDir) + "' for reading.");
						for (String sTemp02 : new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[1], this.defaultDir)).readTextFile(((this.objNetworkSettings.codepage.isEmpty()) ? this.defaultCodepage : this.objNetworkSettings.codepage.toString()))) {
							System.out.println(sTemp02);
						}
						break;
					}
					catch (Exception e) {
						System.err.println("The file cannot be read out.");
						break;
					}
				case "rcfdf":
					String thisCommand = this.argsArray[0].toLowerCase();
					try {
						System.out.println("Opening the file of '" + main.startIt.pathConverted(this.argsArray[1], this.defaultDir) + "' for running commands in it.");
						for (String sTemp02 : new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[1], this.defaultDir)).readTextFile(((this.objNetworkSettings.codepage.isEmpty()) ? this.defaultCodepage : this.objNetworkSettings.codepage.toString()))) {
							String sTemp02_01 = sTemp02.toLowerCase().trim();
							sTemp02_01 = ((sTemp02_01.length() >= thisCommand.length() + 1) ? sTemp02_01.substring(0, thisCommand.length() + 1) : sTemp02_01);
							System.out.println("> " + sTemp02);
							if (sTemp02_01.equals(thisCommand + " ")) {
								System.out.println("!!! \"" + sTemp02 + "\" is skipped due to possible recursion and a stack overflow.");
							} else {
								if (
										new Commands(
												this.objNetworkSettings,
												this.objOracleSettings,
												this.objMySQLSettings,
												this.defaultProxyPort,
												this.defaultCodepage,
												this.HigherColLim,
												this.tempVar01,
												this.defaultDir,
												this.cantChngDir,
												this.unavailable,
												this.undef,
												this.httpServer,
												this.x,
												this.argsArray,
												this.lst_obj,
												sTemp02,
												this.s_converted
												).execCommand()
										) {
									break;
								}
							}
						}
						break;
					}
					catch (Exception e) {
						System.err.println("The file cannot be read out.");
						break;
					}
				case "mkdir": case "md":
					this.argsArray[1] = this.s.substring(this.argsArray[0].length() + 1);
					try {
						if ((this.argsArray[1] != null) && (!this.argsArray[1].isEmpty())) {
							if (new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), "").mkdir()) {
								System.out.println(main.startIt.result(true));
							} else {
								System.out.println(main.startIt.result(false));
							}
						}
					}
					catch (Exception e) {
						System.err.println(e.toString());
					}
					break;
				case "rmdir": case "rd":
					this.argsArray[1] = this.s.substring(this.argsArray[0].length() + 1);
					try {
						if ((this.argsArray[1] != null) && (!this.argsArray[1].isEmpty())) {
							BasicOperations objRmDir = new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), "");
							if ((!objRmDir.exists()) || (!objRmDir.isDirectory())) {
								System.out.println(main.startIt.result(false));
							} else {
								if (objRmDir.delete()) {
									System.out.println(main.startIt.result(true));
								} else {
									System.out.println(main.startIt.result(false));
								}
							}
						}
					}
					catch (Exception e) {
						System.err.println(e.toString());
					}
					break;
				case "grep":
					if (((this.argsArray[1] != null) && (!this.argsArray[1].isEmpty())) && ((this.argsArray[2] != null) && (!this.argsArray[2].isEmpty()))) {
						String fileMGrep = main.startIt.pathConverted(this.argsArray[1], this.defaultDir);
						String grepPatternMGrep = this.s.substring(this.argsArray[0].length() + this.argsArray[1].length() + 2);
						main.startIt.greppedFile(fileMGrep, grepPatternMGrep, objNetworkSettings, this.defaultCodepage);
					}
					break;
				case "mgrep":
					if (((this.argsArray[1] != null) && (!this.argsArray[1].isEmpty())) && ((this.argsArray[2] != null) && (!this.argsArray[2].isEmpty())) && ((this.argsArray[3] != null) && (!this.argsArray[3].isEmpty()))) {
						String fileMGrep2 = main.startIt.pathConverted(this.argsArray[1], this.defaultDir);
						String filePatternMGrep2 = this.argsArray[2];
						String grepPatternMGrep2 = this.s.substring(this.argsArray[0].length() + this.argsArray[1].length() + this.argsArray[2].length() + 3);
						try {
							String[] getFilesMGrep = new BasicOperations("", "").findFiles(fileMGrep2, filePatternMGrep2, (byte) 1);
							for (String arrTemp2 : getFilesMGrep) {
								java.io.File greppedFileObj = new java.io.File(arrTemp2);
								if ((greppedFileObj.isFile()) && (greppedFileObj.canRead())) {
									System.out.println("Looking for the pattern in the file of " + "\"" + arrTemp2 + "\"" + "...");
									main.startIt.greppedFile(arrTemp2, grepPatternMGrep2, objNetworkSettings, this.defaultCodepage);
								}
							}
							System.out.println(String.valueOf("\n" + getFilesMGrep.length) + " items have been scanned.\n");
						}
						catch (Exception e) {
							System.err.println(e.toString());
						}
					}
					break;
				case "newnym":
					final String hintNEWNYM = "Type \"hint newnym\" to find out the proper usage of the command.", natPortNumberTor = "The port number should be a natural number that isn't greater than 65535.";
					if (
							((this.argsArray[1] == null) || (this.argsArray[1].isEmpty()))
							|| ((this.argsArray[2] == null) || (this.argsArray[2].isEmpty()))
							|| ((this.argsArray[3] == null) || (this.argsArray[3].isEmpty()))
							) {
						System.err.println("It's an erroneous use of the \"newnym\" command.");
						System.err.println(hintNEWNYM);
						break;
					}
					int torPort = 9051;
					try {
						torPort = Integer.valueOf(this.argsArray[2]).intValue();
					}
					catch (NumberFormatException e) {
						System.err.println(natPortNumberTor);
						System.err.println(hintNEWNYM);
						break;
					}
					if ((torPort < 1) || (torPort > 65535)) {
						System.err.println(natPortNumberTor);
						System.err.println(hintNEWNYM);
						break;
					}
					String torHost = this.argsArray[1];
					String torPassword = this.s.substring(this.argsArray[0].length() + this.argsArray[1].length() + this.argsArray[2].length() + 3);
					try {
						new Tor(torHost, torPort, torPassword, ((this.objNetworkSettings.codepage.isEmpty()) ? this.defaultCodepage : this.objNetworkSettings.codepage.toString())).setNEWNYM();
					}
					catch (java.net.UnknownHostException e) {
						System.err.println("The IP address you have pointed out for Tor, is incorrect.");
					}
					catch (IOException e) {
						System.err.println("An internal error has occurred while connecting.");
						System.err.println(e.toString());
					}
					break;
				case "whois":
					final String whoisHost = "whois.ripe.net"; // WHOIS server's host
					final int whoisPort = 43; // WHOIS server's port
					String ip = this.s.substring(this.argsArray[0].length() + 1);
					try {
						SocketXT objSocketXT = new SocketXT(
								(
										((this.objNetworkSettings.proxyhost == null) || (this.objNetworkSettings.proxyhost.isEmpty())) ? // direct connection?
												Proxy.NO_PROXY
												: new Proxy(
														Proxy.Type.HTTP,
														new InetSocketAddress(
																this.objNetworkSettings.proxyhost,
																((this.objNetworkSettings.proxyport < 1) ? this.defaultProxyPort : this.objNetworkSettings.proxyport)
																)
														)
										),
								(
										((this.objNetworkSettings.proxyhost == null) || (this.objNetworkSettings.proxyhost.isEmpty()) || (this.objNetworkSettings.uName == null) || (this.objNetworkSettings.uName.isEmpty())) ? // direct connection?
												false
												: true
										),
								(
										((this.objNetworkSettings.uName == null) || (this.objNetworkSettings.uName.isEmpty())) ?
												""
												: this.objNetworkSettings.uName
										),
								(
										((this.objNetworkSettings.uPass == null) || (this.objNetworkSettings.uPass.isEmpty())) ?
												""
												: this.objNetworkSettings.uPass
										),
								(
										(this.objNetworkSettings.noproxy == null) ?
												new String[] {}
												: this.objNetworkSettings.noproxy
										),
								new InetSocketAddress(whoisHost, whoisPort) // a host to get connected to
								);
						System.out.println("We are trying to get a WHOIS response for " + "\"" + ip + "\"" + " from " + whoisHost + ":" + String.valueOf(whoisPort) + "...");
						String[] resp = new WhoIs(
								objSocketXT,
								(
										((this.objNetworkSettings.codepage == null) || (this.objNetworkSettings.codepage.isEmpty())) ?
												this.defaultCodepage
												: this.objNetworkSettings.codepage
										),
								ip
								).whoisResponse();
						if (resp.length < 1) {
							System.out.println("Nothing has received from the server.");
						} else {
							System.out.println("The answer has come.\n");
							for (String arrTemp2 : resp) {
								System.out.println(arrTemp2);
							}
						}
					}
					catch (Exception e) {
						System.err.println("\"" + e.getMessage() + "\"" + ": This has happened during executing the request.");
					}
					break;
				case "dnsbl":
					String ip2 = this.s.substring(this.argsArray[0].length() + 1);
					if (new DroneBL(ip2)._isBlacklisted()) {
						System.out.println("This IP address seems to be blacklisted.");
					} else {
						System.out.println("This IP address isn't blacklisted.");
					}
					break;
				case "say": case "echo":
					System.out.println(this.s.substring(this.argsArray[0].length() + 1));
					break;
				case "oracle_user":
					this.objOracleSettings.oracle_user = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "oracle_password":
					this.objOracleSettings.oracle_password = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "oracle_url":
					this.objOracleSettings.oracle_url = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "oracle_ctrl_line":
					this.objOracleSettings.oracle_ctrl_line = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "oracle_col_size":
					try {
						this.tempVar01 = Integer.parseInt(s.substring(this.argsArray[0].length() + 1));
						if (this.tempVar01 < 1) {
							this.tempVar01 = 0;
						}
						if (this.tempVar01 > this.HigherColLim) {
							this.tempVar01 = this.HigherColLim;
						}
						this.objOracleSettings.oracle_col_size = this.tempVar01;
						main.startIt._changed(this.argsArray[0]);
					}
					catch(Exception e) {
						System.err.println("A natural number is expected.");
					}
					break;
				case "use_old_oracle":
					if ((this.argsArray[1] == null) || (this.argsArray[1].isEmpty())) {
						System.err.println("Unknown parameter.");
					} else {
						if (this.argsArray[1].toLowerCase().equals("true")) { // http://stackoverflow.com/questions/9156379/ora-01882-timezone-region-not-found
							System.setProperty("oracle.jdbc.timezoneAsRegion", "false");
							System.out.println("Emulating the use of an old Oracle DBMS has been activated.");
						} else {
							if (this.argsArray[1].toLowerCase().equals("false")) {
								System.setProperty("oracle.jdbc.timezoneAsRegion", "true");
								System.out.println("Support of an old Oracle DBMS is disabled.");
							} else {
								System.err.println("Unknown parameter.");
							}
						}
					}
					break;
				case "oracle_query":
					if (
							((this.objOracleSettings.oracle_user.isEmpty()) || (this.objOracleSettings.oracle_user == null))
							|| ((this.objOracleSettings.oracle_password.isEmpty()) || (this.objOracleSettings.oracle_password == null))
							|| ((this.objOracleSettings.oracle_url.isEmpty()) || (this.objOracleSettings.oracle_url == null))
							|| ((this.objOracleSettings.oracle_ctrl_line.isEmpty()) || (this.objOracleSettings.oracle_ctrl_line == null))
							) {
						System.out.println("Some parameters are undefined for Oracle.");
						break;
					}
					this.objOracleSettings.oracle_query = s.substring(this.argsArray[0].length() + 1);
					System.out.println("Establishing connection to the Oracle database...");

					try {
						new Tables().printTable(
								new Oracle_DB(this.objOracleSettings.oracle_user, this.objOracleSettings.oracle_password, this.objOracleSettings.oracle_url, this.objOracleSettings.oracle_ctrl_line).executeQuery(
										this.objOracleSettings.oracle_query
										),
								this.objOracleSettings.oracle_col_size
								); // printing the table
					}
					catch(Exception e) {
						System.out.println();
						System.err.println(main.startIt.result(false));
						System.err.println("~ " + e.toString());
					}
					System.out.println(main.startIt.result(true));
					break;
				case "oracle_file2query":
					try {
						if (
								((this.objOracleSettings.oracle_user.isEmpty()) || (this.objOracleSettings.oracle_user == null))
								|| ((this.objOracleSettings.oracle_password.isEmpty()) || (this.objOracleSettings.oracle_password == null))
								|| ((this.objOracleSettings.oracle_url.isEmpty()) || (this.objOracleSettings.oracle_url == null))
								|| ((this.objOracleSettings.oracle_ctrl_line.isEmpty()) || (this.objOracleSettings.oracle_ctrl_line == null))
								) {
							System.out.println("Some parameters are undefined for Oracle.");
							break;
						}
						Function<String[], String> convertOracleQuery = new Function<String[], String>() {
							@Override
							public String apply(String[] from) {
								int c = 0;
								String s2;
								StringBuilder s = new StringBuilder();
								for (String sTemp02 : from) {
									s.append(sTemp02 + "\n");
								}
								for (int x = s.length() - 1; x >= 0; x--) {
									if (!(String.valueOf(s.charAt(x)).equals("\n"))) {
										break;
									}
									c++;
								}
								s2 = s.substring(0, s.length() - c);
								return s2;
							}
						};
						this.objOracleSettings.oracle_query = convertOracleQuery.apply(new BasicOperations(main.startIt.pathConverted(s.substring(this.argsArray[0].length() + 1), this.defaultDir), main.startIt.pathConverted(this.argsArray[0], this.defaultDir)).readTextFile(((this.objNetworkSettings.codepage.isEmpty()) ? this.defaultCodepage : this.objNetworkSettings.codepage.toString())));
						System.out.println("Fetching a result from the SQL query as follows:\n\n" + this.objOracleSettings.oracle_query + "\n\n");

						System.out.println("Establishing connection to the Oracle database...");
						try {
							new Tables().printTable(
									new Oracle_DB(this.objOracleSettings.oracle_user, this.objOracleSettings.oracle_password, this.objOracleSettings.oracle_url, this.objOracleSettings.oracle_ctrl_line).executeQuery(
											this.objOracleSettings.oracle_query
											),
									this.objOracleSettings.oracle_col_size
									); // printing the table
						}
						catch(Exception e) {
							System.out.println();
							System.err.println(main.startIt.result(false));
							System.err.println("~ " + e.toString());
						}
						System.out.println(main.startIt.result(true));
						break;
					}
					catch (Exception e) {
						System.err.println("The file cannot be read out.");
						break;
					}
				case "mysql_user":
					this.objMySQLSettings.mysql_user = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "mysql_password":
					this.objMySQLSettings.mysql_password = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "mysql_url":
					this.objMySQLSettings.mysql_url = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "mysql_ctrl_line":
					this.objMySQLSettings.mysql_ctrl_line = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "mysql_col_size":
					try {
						this.tempVar01 = Integer.parseInt(this.s.substring(this.argsArray[0].length() + 1));
						if (this.tempVar01 < 1) {
							this.tempVar01 = 0;
						}
						if (this.tempVar01 > this.HigherColLim) {
							this.tempVar01 = this.HigherColLim;
						}
						this.objMySQLSettings.mysql_col_size = this.tempVar01;
						main.startIt._changed(this.argsArray[0]);
					}
					catch(Exception e) {
						System.err.println("A natural number is expected.");
					}
					break;
				case "mysql_codepage":
					this.objMySQLSettings.mysql_codepage = this.s.substring(this.argsArray[0].length() + 1);
					main.startIt._changed(this.argsArray[0]);
					break;
				case "mysql_query":
					if (
							((this.objMySQLSettings.mysql_user.isEmpty()) || (this.objMySQLSettings.mysql_user == null))
							|| ((this.objMySQLSettings.mysql_password.isEmpty()) || (this.objMySQLSettings.mysql_password == null))
							|| ((this.objMySQLSettings.mysql_url.isEmpty()) || (this.objMySQLSettings.mysql_url == null))
							|| ((this.objMySQLSettings.mysql_ctrl_line.isEmpty()) || (this.objMySQLSettings.mysql_ctrl_line == null))
							) {
						System.out.println("Some parameters are undefined for MySQL.");
						break;
					}
					this.objMySQLSettings.mysql_query = this.s.substring(this.argsArray[0].length() + 1);
					System.out.println("Establishing connection to the MySQL database...");
					try {
						new Tables().printTable(
								new MySQL_DB(this.objMySQLSettings.mysql_user, this.objMySQLSettings.mysql_password, this.objMySQLSettings.mysql_url, this.objMySQLSettings.mysql_ctrl_line, this.objMySQLSettings.mysql_codepage).executeQuery(
										this.objMySQLSettings.mysql_query
										),
								this.objMySQLSettings.mysql_col_size
								); // printing the table
					}
					catch(Exception e) {
						System.out.println();
						System.err.println(main.startIt.result(false));
						System.err.println("~ " + e.toString());
					}
					System.out.println(main.startIt.result(true));
					break;
				case "mysql_file2query":
					try {
						if (
								((this.objMySQLSettings.mysql_user.isEmpty()) || (this.objMySQLSettings.mysql_user == null))
								|| ((this.objMySQLSettings.mysql_password.isEmpty()) || (this.objMySQLSettings.mysql_password == null))
								|| ((this.objMySQLSettings.mysql_url.isEmpty()) || (this.objMySQLSettings.mysql_url == null))
								|| ((this.objMySQLSettings.mysql_ctrl_line.isEmpty()) || (this.objMySQLSettings.mysql_ctrl_line == null))
								) {
							System.out.println("Some parameters are undefined for MySQL.");
							break;
						}
						Function<String[], String> convertMySQLQuery = new Function<String[], String>() {
							@Override
							public String apply(String[] from) {
								int c = 0;
								String s2;
								StringBuilder s = new StringBuilder();
								for (String sTemp02 : from) {
									s.append(sTemp02 + "\n");
								}
								for (int x = s.length() - 1; x >= 0; x--) {
									if (!(String.valueOf(s.charAt(x)).equals("\n"))) {
										break;
									}
									c++;
								}
								s2 = s.substring(0, s.length() - c);
								return s2;
							}
						};
						this.objMySQLSettings.mysql_query = convertMySQLQuery.apply(new BasicOperations(main.startIt.pathConverted(s.substring(this.argsArray[0].length() + 1), this.defaultDir), main.startIt.pathConverted(this.argsArray[0], this.defaultDir)).readTextFile(((this.objNetworkSettings.codepage.isEmpty()) ? this.defaultCodepage : this.objNetworkSettings.codepage.toString())));
						System.out.println("Fetching a result from the SQL query as follows:\n\n" + this.objMySQLSettings.mysql_query + "\n\n");

						System.out.println("Establishing connection to the MySQL database...");
						try {
							new Tables().printTable(
									new MySQL_DB(this.objMySQLSettings.mysql_user, this.objMySQLSettings.mysql_password, this.objMySQLSettings.mysql_url, this.objMySQLSettings.mysql_ctrl_line, this.objMySQLSettings.mysql_codepage).executeQuery(
											this.objMySQLSettings.mysql_query
											),
									this.objMySQLSettings.mysql_col_size
									); // printing the table
						}
						catch(Exception e) {
							System.out.println();
							System.err.println(main.startIt.result(false));
							System.err.println("~ " + e.toString());
						}
						System.out.println(main.startIt.result(true));
						break;
					}
					catch (Exception e) {
						System.err.println("The file cannot be read out.");
						break;
					}
				case "hint":
					if ((this.argsArray[1] == null) || (this.argsArray[1].isEmpty())) {
						System.out.println("This command has been used incorrectly.\nType \"hint hint\" to find out what went wrong.");
					} else {
						boolean flag01 = false;
						for (this.x = 0; this.x < this.cmdList.length / 2; this.x++) {
							if (this.cmdList[2 * this.x].equals(this.argsArray[1])) {
								System.out.println(this.cmdList[2 * this.x + 1]);
								flag01 = true; // found
								break;
							}
						}
						if (!flag01) {
							System.out.println("This command isn't in the list.");
						}
					}
					break;
				case "copy": case "cp":
					try {
						System.out.println(main.startIt.result(new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).binaryCopy()));
						break;
					}
					catch (Exception e) {
						System.err.println("Error on copying.");
						break;
					}
				case "http":
					final String hintHTTP = "Type \"hint http\" to find out the proper usage of the \"http\" command.", natPortNumber = "The port number should be a natural number that isn't greater than 65535.";
					if ((this.argsArray[1] == null) || (this.argsArray[1].isEmpty())) {
						System.err.println("Not enough parameters.");
						System.err.println(hintHTTP);
					}
					switch (this.argsArray[1].toLowerCase()) {
					case "status":
						if ((this.httpServer != null) && (this.httpServer.isAlive())) {
							System.out.println("The HTTP server is running.");
						} else {
							System.out.println("The HTTP server is not running.");
						}
						break;
//					case "stop": // Stopping the server
//						if ((this.httpServer != null) && (this.httpServer.isAlive())) {
//							this.httpServer.stop();
//							this.httpServer = null;
//							System.out.println("The HTTP server has been stopped.");
//						} else {
//							System.out.println("The HTTP server is not running.");
//						}
//						break;
					case "start": // Starting the server
						int httpPort = 80;
						if ((this.argsArray[2] == null) || (this.argsArray[2].isEmpty()) || (this.argsArray[3] == null) || (this.argsArray[3].isEmpty())) {
							System.err.println("Incorrect usage of the command. A directory and a TCP port are required in the command.");
							System.err.println(hintHTTP);
						}
						try {
							httpPort = Integer.valueOf(this.argsArray[3]).intValue();
						}
						catch (NumberFormatException e) {
							System.err.println(natPortNumber);
							System.err.println(hintHTTP);
							break;
						}
						if ((httpPort < 1) || (httpPort > 65535)) {
							System.err.println(natPortNumber);
							System.err.println(hintHTTP);
							break;
						}
						File httpDir = new File(main.startIt.pathConverted(this.argsArray[2], this.defaultDir));
						if ((httpDir.exists()) && (httpDir.isDirectory())) {
							if ((this.httpServer != null) && (this.httpServer.isAlive())) {
								System.out.println("The HTTP server has already been running. There's no need to start it once again.");
							} else {
								try {
									this.httpServer = new SimpleWebServer(httpDir, httpPort);
									System.out.println("The HTTP server is running now.");
								}
								catch (IOException e) {
									System.err.println("Something can have gone wrong. It was impossible to run the server.");
								}
							}
						} else {
							System.err.println("There is no such a directory.");
						}
						break;
					default:
						System.err.println("An unknown option is defined.");
						System.err.println(hintHTTP);
					}
					break;
				case "fc": case "diff":
					try {
						System.out.println("Comparing whether the two files are equal: \"" + main.startIt.pathConverted(this.argsArray[1], this.defaultDir) + "\" and \"" + main.startIt.pathConverted(this.argsArray[2], this.defaultDir) + "\".");
						System.out.println(main.startIt.result(new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).binaryFileCompare()));
						break;
					}
					catch (Exception e) {
						System.err.println(e.getMessage());
						break;
					}
				case "size":
					BasicOperations objFileSize = new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), "");
					if (objFileSize.exists()) {
						System.out.println("File's size: " + String.valueOf(objFileSize.length()) + " byte(s).");
					} else {
						System.out.println("This file cannot be found.");
						System.out.println("Try using \".\", \"..\", \"~\", \"" + System.getProperty(main.startIt.fileSeparator) + "\" at the beginning of the path.");
					}
					break;
				case "mv": case "rename": case "ren":
					System.out.println(main.startIt.result(new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).renameTo()));
					break;
				// The further Java methods have been inherited from the java.io.File class
				case "erase": case "rm": case "del": case "delete":
					System.out.println(main.startIt.result(new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).delete()));
					break;
				case "getname":
					try {
						System.out.println(new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).getAbsolutePath());
						break;
					}
					catch (Exception e) {
						System.err.println("No file or directory has been specified.");
						break;
					}
				case "dir": case "ls":
					try {
						for (String sTemp03 : new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).dir()) {
							System.out.println(sTemp03);
						}
						System.out.println(System.getProperty(main.startIt.sysHome));
						break;
					}
					catch (Exception e) {
						System.err.println("A non-existent directory has been defined, or you do not have permission to access it.");
						break;
					}
				case "mlist":
					if (((this.argsArray[1] != null) && (!this.argsArray[1].isEmpty())) && ((this.argsArray[2] != null) && (!this.argsArray[2].isEmpty()))) {
						String fileMList = main.startIt.pathConverted(this.argsArray[1], this.defaultDir);
						String grepPatternMList = this.s.substring(this.argsArray[0].length() + this.argsArray[1].length() + 2);
						try {
							for (String arrTemp3 : new BasicOperations(fileMList, null).dirMask(grepPatternMList)  ) {
								System.out.println(arrTemp3);
							}
							System.out.println(System.getProperty(main.startIt.sysHome));
						}
						catch (Exception e) {
							System.err.println("A non-existent directory has been defined, or you do not have permission to access it.");
						}
					}
					break;
				case "cd": case "chdir":
					this.argsArray[1] = this.s.substring(this.argsArray[0].length() + 1);
					try {
						System.out.println("Changing to \"" + main.startIt.pathConverted(this.argsArray[1], this.defaultDir) + "\".");
						System.setProperty(main.startIt.sysHome, main.startIt.pathConverted(this.argsArray[1], this.defaultDir));
						main.startIt._changed("The directory");
						break;
					}
					catch (Exception e) {
						System.err.println(this.cantChngDir);
						break;
					}
				case "url": case "wget":
					try {
						System.out.println("Opening the URL of '" + this.argsArray[1] + "' for reading.");
						for (String sTemp04 : ((
								!(this.objNetworkSettings.proxyhost.isEmpty()) // if thru a proxy server
								) ? new BasicOperations(this.argsArray[1], "").getWebpageOverProxy(this.objNetworkSettings.codepage, this.objNetworkSettings.proxyhost, ((this.objNetworkSettings.proxyport < 1) ? this.defaultProxyPort : this.objNetworkSettings.proxyport), this.objNetworkSettings.uName, this.objNetworkSettings.uPass, this.objNetworkSettings.noproxy) : new BasicOperations(this.argsArray[1], "").getWebpage(this.objNetworkSettings.codepage))) {
							System.out.println(sTemp04);
						}
						break;
					}
					catch (Exception e) {
						System.err.println("The URL cannot be read out.");
						break;
					}
				case "dump":
					try {
						System.out.println("Saving the history to the file...");
						String[] stringDump = new String[] {};
						stringDump = this.lst_obj.toArray(new String[this.lst_obj.size()]); // dumping into a normal array
						new BasicOperations(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).writeTextFile(stringDump, this.objNetworkSettings.codepage);
						System.out.println("Done.");
						break;
					}
					catch (Exception e) {
						System.err.println("Error opening the file for writing.");
						break;
					}
				case "mim":
					if ((this.argsArray[1] != null) && (this.argsArray[2] != null) && (this.argsArray[3] != null)) {
						if ((java.nio.charset.Charset.isSupported(this.argsArray[2].toUpperCase())) && (java.nio.charset.Charset.isSupported(this.argsArray[3].toUpperCase()))) {
							try {
								String[] mimLines = null;
								mimLines = new Coding().parseMIM(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), this.argsArray[2], this.argsArray[3]);
								for (String sTemp07 : mimLines) {
									if (this.objNetworkSettings.codepage.isEmpty()) {
										System.out.println(sTemp07);
									} else {
										System.out.println(new String( sTemp07.getBytes(this.argsArray[3]), this.objNetworkSettings.codepage ));
									}
								}
							}
							catch (Exception e) {
								System.err.println(e.toString());
							}
						} else {
							System.out.println("Sorry! This codepage is not supported.");
							System.out.println("Type \"charsets\" to get a list of all the available codepages.");
						}
					}
					break;
				case "mim2file":
					if ((this.argsArray[1] != null) && (this.argsArray[2] != null) && (this.argsArray[3] != null) && (this.argsArray[4] != null)) {
						if ((java.nio.charset.Charset.isSupported(this.argsArray[2].toUpperCase())) && (java.nio.charset.Charset.isSupported(this.argsArray[3].toUpperCase()))) {
							try {
								new BasicOperations(main.startIt.pathConverted(this.argsArray[4], this.defaultDir), "").writeTextFile(
										new Coding().parseMIM(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), this.argsArray[2], this.argsArray[3]),
										this.argsArray[3]
										);
								System.out.println("See the file of \"" + main.startIt.pathConverted(this.argsArray[4], this.defaultDir) + "\".");
							}
							catch (Exception e) {
								System.err.println(e.toString());
							}
						} else {
							System.out.println("Sorry! This codepage is not supported.");
							System.out.println("Type \"charsets\" to get a list of all the available codepages.");
						}
					}
					break;
				case "codepage":
					try {
						if (this.argsArray[1].isEmpty()) {
							this.objNetworkSettings.codepage = "";
							System.err.println(this.undef);
						} else {
							if (java.nio.charset.Charset.isSupported(this.argsArray[1].toUpperCase())) {
								this.objNetworkSettings.codepage = this.argsArray[1].toUpperCase(); 
								System.out.println("The codepage has been successfully changed to " + this.objNetworkSettings.codepage.toString() + ".");
							} else {
								System.out.println("Sorry! This codepage is not supported.");
								System.out.println("Type \"charsets\" to get a list of all the available codepages.");
							}
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.codepage = "";
						System.err.println(this.undef);
						break;
					}
				case "proxyhost":
					try {
						if (this.argsArray[1].isEmpty()) {
							this.objNetworkSettings.proxyhost = "";
							System.err.println(this.undef);
						} else {
							this.objNetworkSettings.proxyhost = this.argsArray[1]; 
							System.out.println("The proxy host has been successfully changed to " + this.objNetworkSettings.proxyhost.toString() + ".");
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.proxyhost = "";
						System.err.println(this.undef);
						break;
					}
				case "proxyport":
					try {
						if (this.argsArray[1].isEmpty()) {
							this.objNetworkSettings.proxyport = 0;
							System.err.println(this.undef);
						} else {
							this.objNetworkSettings.proxyport = Integer.parseInt(this.argsArray[1]); 
							System.out.println("The proxy port has been successfully changed to " + Integer.toString(this.objNetworkSettings.proxyport) + ".");
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.proxyport = 0;
						System.err.println(this.undef);
						break;
					}
				case "proxyuser":
					try {
						if (this.argsArray[1].isEmpty()) {
							this.objNetworkSettings.uName = "";
							System.err.println(this.undef);
						} else {
							this.objNetworkSettings.uName = this.argsArray[1]; 
							System.out.println("The proxy user has been successfully changed to " + this.objNetworkSettings.uName.toString() + ".");
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.uName = "";
						System.err.println(this.undef);
						break;
					}
				case "proxypassword":
					try {
						if (this.argsArray[1].isEmpty()) {
							this.objNetworkSettings.uPass = "";
							System.err.println(this.undef);
						} else {
							this.objNetworkSettings.uPass = this.argsArray[1]; 
							System.out.println("The proxy password has been successfully changed to " + this.objNetworkSettings.uPass.toString() + ".");
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.uPass = "";
						System.err.println(this.undef);
						break;
					}
				case "netcalc": case "cidr": // http://en.wikipedia.org/wiki/Classless_Inter-Domain_Routing#CIDR_notation
					try {
						if (this.argsArray[1].isEmpty()) {
							System.err.println(this.undef);
						} else {
							System.out.println("The IPv4 block " + this.argsArray[1] + " represents the IPv4 addresses as follows: " + new BasicOperations("", "").netcalc(this.argsArray[1], this.objNetworkSettings.noproxy) + "."); 
						}
						break;
					}
					catch (Exception e) {
						System.err.println(e.toString());
						break;
					}
				case "ff": case "find":
					try {
						if (this.argsArray[1].isEmpty()) {
							System.err.println(this.undef);
						} else {
							System.out.println("Getting recursively files and directories by the pathname - wait...");
							String[] ffObj = new BasicOperations("", "").findFiles(main.startIt.pathConverted(this.argsArray[1], this.defaultDir), null, (byte) 1);
							for (String sTemp06 : ffObj) {
								System.out.println(sTemp06);
							}
							System.out.println("Found: " + String.valueOf(ffObj.length) + " items.");
						}
						break;
					}
					catch (Exception e) {
						System.err.println(e.toString());
						break;
					}
				case "noproxy": case "no-proxy": case "no_proxy":
					try {
						String tempNProxy = this.s.substring(this.argsArray[0].length() + 1);
						if (tempNProxy.split(",").length == 0) {
							this.objNetworkSettings.noproxy = new String[] {};
							System.err.println(this.undef);
						} else {
							this.objNetworkSettings.noproxy = tempNProxy.split(",");
							for (this.x = 0; this.x < this.objNetworkSettings.noproxy.length; this.x++) {
								this.objNetworkSettings.noproxy[this.x] = this.objNetworkSettings.noproxy[this.x].trim();
							}
							System.out.println("The noproxy environment variable has been successfully changed to " + Arrays.toString(this.objNetworkSettings.noproxy) + ".");
						}
						break;
					}
					catch (Exception e) {
						this.objNetworkSettings.noproxy = new String[] {};
						System.err.println(this.undef);
						break;
					}
				case "exec": // http://blog.eqlbin.ru/2010/09/java.html
					ArrayList<String> procArgs = new ArrayList<String>();
					try {
						for (this.x = 1; this.x < this.argsArray.length; this.x++) {
							if ((this.argsArray[this.x] == null) || (this.argsArray[this.x].isEmpty())) {
								break;
							}
							procArgs.add(this.argsArray[this.x]);
						}
						if (procArgs.size() < 1) {
							System.err.println(this.undef);
						} else {
							System.out.println("Errorlevel: " + String.valueOf(new External().execCommand(procArgs, System.getProperty(main.startIt.sysHome), this.objNetworkSettings.codepage)) + ".");
						}
					}
					catch (Exception e) {
						System.err.println(e.toString());
					}
					break;
				case "webpage2file":
					try {
						if ((!(this.argsArray[1].isEmpty())) && (!(this.argsArray[2].isEmpty()))) {
							System.out.println("Saving the web page of " + this.argsArray[1] + " to the file of " + main.startIt.pathConverted(this.argsArray[2], this.defaultDir) + "...");
							new BasicOperations(main.startIt.pathConverted(this.argsArray[2], this.defaultDir), "").writeTextFile(
									(
											!(this.objNetworkSettings.proxyhost.isEmpty()) // if thru a proxy server
											) ? new BasicOperations(this.argsArray[1], "").getWebpageOverProxy(this.objNetworkSettings.codepage, this.objNetworkSettings.proxyhost, ((this.objNetworkSettings.proxyport < 1) ? this.defaultProxyPort : this.objNetworkSettings.proxyport), this.objNetworkSettings.uName, this.objNetworkSettings.uPass, this.objNetworkSettings.noproxy) : new BasicOperations(this.argsArray[1], "").getWebpage(this.objNetworkSettings.codepage),
													this.objNetworkSettings.codepage
									);
							System.out.println("Done.");
						}
						break;
					}
					catch (Exception e) {
						System.err.println("Some unexpected error has occurred.");
						break;
					}
				case "binaryurl2file":
					try {
						System.out.println(main.startIt.result(
								(
										this.objNetworkSettings.proxyhost.isEmpty() // is it direct connection?
										) ? new BasicOperations(this.argsArray[1], main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).binarySaveFromURL("", 0, "", "", this.objNetworkSettings.noproxy) : new BasicOperations(this.argsArray[1], main.startIt.pathConverted(this.argsArray[2], this.defaultDir)).binarySaveFromURL(this.objNetworkSettings.proxyhost, this.objNetworkSettings.proxyport, this.objNetworkSettings.uName, this.objNetworkSettings.uPass, this.objNetworkSettings.noproxy)
								));
						break;
					}
					catch (Exception e) {
						System.err.println("Error while binary saving to the file from the URL.");
						break;
					}
				case "iconv": // iconv codepage1 _file1 codepage2 _file2
					String codepage1 = new String();
					String codepage2 = new String();
					String _file1 = new String();
					String _file2 = new String();
					if (
							((this.argsArray[1] == null) || (this.argsArray[1].isEmpty())) // codepage1
							|| ((this.argsArray[2] == null) || (this.argsArray[2].isEmpty())) // _file1
							|| ((this.argsArray[3] == null) || (this.argsArray[3].isEmpty())) // codepage2
							|| ((this.argsArray[4] == null) || (this.argsArray[4].isEmpty())) // _file2
							) {
						System.err.println("Wrong usage.");
					} else {
						codepage1 = this.argsArray[1];
						codepage2 = this.argsArray[3];
						_file1 = main.startIt.pathConverted(this.argsArray[2], this.defaultDir);
						_file2 = main.startIt.pathConverted(this.argsArray[4], this.defaultDir);
						if ((!(Charset.isSupported(codepage1))) || (!(Charset.isSupported(codepage2)))) {
							System.err.println("An unsupported codepage has been found as a parameter.");
							System.err.println("Type \"charsets\" to get a list of all the available codepages.");
						} else {
							try {
								new BasicOperations(_file2, "").writeTextFile(new BasicOperations(_file1, "").readTextFile(codepage1), codepage2);
								System.out.println("The file \"" + _file2 + "\" is ready.");
							}
							catch(Exception e) {
								System.err.println("I/O error while accessing the files.");
							}
						}
					}
					break;
				}

			}
		}
		return _isExit;
	}

}
